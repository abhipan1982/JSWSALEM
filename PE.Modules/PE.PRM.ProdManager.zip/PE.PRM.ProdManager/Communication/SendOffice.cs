﻿using PE.PRM.Base.Module.Communication;

namespace PE.PRM.ProdManager.Communication
{
  public class SendOffice : ModuleBaseSendOffice
  {
  }
}
