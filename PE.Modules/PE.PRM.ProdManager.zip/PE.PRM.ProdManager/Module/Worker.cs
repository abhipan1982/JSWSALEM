﻿using PE.PRM.Base.Module;

namespace PE.PRM.ProdManager.Module
{
  public class Worker : WorkerBase
  {
  }
}
